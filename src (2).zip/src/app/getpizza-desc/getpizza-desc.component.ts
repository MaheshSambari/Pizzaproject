import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-getpizza-desc',
  templateUrl: './getpizza-desc.component.html',
  styleUrls: ['./getpizza-desc.component.css']
})
export class GetpizzaDescComponent implements OnInit {

  constructor(private pservice : PizzaService,private router: Router) { }
public pizza:any=[]
  ngOnInit(): void {
    this.getPizza()
  }

  getPizza(){
    this.pservice.getPizzaDesc().subscribe(
      data => this.pizza=data
      )
  }

  public result:any

  deletePizza(pizzaId:Number){
    this.pservice.deletePizza(pizzaId).subscribe(
    data=>{
      console.log(data)
      this.result=data
      this.getPizza()
     }

  )
    }

  updateCost(pizza:any)
  {
   this.router.navigate(['/update',pizza.pizzaId])
  }
}

