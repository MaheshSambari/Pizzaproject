import { Component, OnInit } from '@angular/core';
import { Pizza } from '../pizza';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-get-pizza-by-type',
  templateUrl: './get-pizza-by-type.component.html',
  styleUrls: ['./get-pizza-by-type.component.css']
})
export class GetPizzaByTypeComponent implements OnInit {

  constructor(private pservice:PizzaService) { }

  ngOnInit(): void {
  }
  public pizza:any=[]
  public msg:any
  pizza2 = new Pizza(0,'','','','')
  
  getPizzaByType(pizza1:any){
    console.log(pizza1.pizzaType)
    this.pservice.getPizzaByType(pizza1.pizzaType).subscribe(
      data=>{
        console.log(data)
        this.pizza=data
        this.msg=''
       },
       error=>{
         console.log(error)
         this.msg=error.error.message
       }
  
  
    )
  
     }

     deletePizza(pizzaId:Number){
    //   this.pservice.deletePizza(pizzaId).subscribe(
    //   data=>{
    //     console.log(data)
    //     this.result=data
    //     this.getPizza()
    //    }
  
    // )
      }
  
    updateCost(pizza:any)
    {
    //  this.router.navigate(['/update',pizza.pizzaId])
    }
    
  
  }
  