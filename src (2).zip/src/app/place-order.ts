import { LineItem } from "./line-item";

export class PlaceOrder<LineItem> {
    constructor(public list:Array<LineItem>,public orderLocation:string,public orderDescription:string,public orderCustomerId:number,public transactionMode:string){}
}
