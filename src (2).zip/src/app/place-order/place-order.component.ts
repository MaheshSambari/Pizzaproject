import { Component, OnInit } from '@angular/core';
import { LineItem } from '../line-item';
import { LineItemService } from '../line-item.service';
import { PizzaOrderService } from '../pizza-order.service';
import { PlaceOrder } from '../place-order';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {
  lineItemModel:LineItem[]=[];

  constructor(private pservice:PizzaOrderService,private lservice:LineItemService) { }
  
  
  ngOnInit(): void {
    this.lservice.getCart(10000).subscribe(data=>{      
      this.lineItemModel=data;
 })
}
  placeModel = new PlaceOrder<LineItem>(this.lineItemModel,'For Family Party','Warangal Kazipet',10000,'default')
  public hasError:boolean=true
  transactionmodes=['Paytm','Phone pe','Amazon','Google Pay','Net Banking','Debit/Credid card','Cash On Delivery','Order Pay Later']

  validateTransaction(transaction:string){
    if(transaction=='default'){
    this.hasError=true;
      }
      else {
        this.hasError=false;
      }
   
   }

   placeOrder(order:any){
    console.log(this.lineItemModel)
    console.log(this.placeModel)
    //console.log(JSON.stringify(this.placeModel))
    // this.pservice.placeOrder(this.placeModel).subscribe(data=>{
    //  console.log(data)
    // })
    }

}
