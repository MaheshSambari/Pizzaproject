import { LineItem } from './line-item';

describe('LineItem', () => {
  it('should create an instance', () => {
    expect(new LineItem('','','','','')).toBeTruthy();
  });
});
