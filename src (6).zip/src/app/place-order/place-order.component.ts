import { Component, OnInit } from '@angular/core';
import { PizzaOrderService } from '../pizza-order.service';
import { PlaceOrder } from '../place-order';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {
  result: any;
  sresult: any;
  public placeModel = new PlaceOrder('','','','default');
  public hasError:boolean=true;

  constructor(private pservice:PizzaOrderService) { }
  ngOnInit(): void {}


  transactionmodes=['Paytm','Phone pe','Amazon','Google Pay','Net Banking','Debit/Credid card','Cash On Delivery','Order Pay Later'];

  validateTransaction(transaction:string){
    if(transaction=='default'){
    this.hasError=true;
      }
      else {
        this.hasError=false;
      }   
   }


   placeOrder(order:any){
       console.log(this.placeModel);
       this.pservice.placeOrder(this.placeModel).subscribe(data=>{
           console.log(data);
           this.result=data;
           this.sresult='';
           this.placeModel = new PlaceOrder('','','','default');
           if(this.result.successMessage.length!=0){
               this.sresult=data;
               this.result='';
               this.placeModel = new PlaceOrder('','','','default');
     }
    },
     error=>{
      console.log(error);
        })
    }
}
