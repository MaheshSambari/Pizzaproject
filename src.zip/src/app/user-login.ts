export class UserLogin {  
    constructor(public userId:any , public userPassword:any){}
}
