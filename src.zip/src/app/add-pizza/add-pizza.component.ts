import { Component, OnInit } from '@angular/core';
import { Pizza } from '../pizza';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-add-pizza',
  templateUrl: './add-pizza.component.html',
  styleUrls: ['./add-pizza.component.css']
})
export class AddPizzaComponent implements OnInit {

  constructor(private pservice:PizzaService) { }
  
   ngOnInit(): void {
     }
 public result:any
 sresult:any
pizzaModel = new Pizza('','','','','')

addPizza(pizza:any){
   this.pservice.savePizza(pizza.value).subscribe(
      data=>{
        console.log(data)
        this.result=data
        this.sresult=''
        this.pizzaModel = new Pizza('','','','','')
        if(this.result.successMessage.length!=0){
          this.sresult=data
          this.result=''
        }
       }

     )
    }

  }
