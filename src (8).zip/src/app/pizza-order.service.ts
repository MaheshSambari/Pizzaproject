import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LineItem } from './line-item';
import { PlaceOrder } from './place-order';

@Injectable({
  providedIn: 'root'
})
export class PizzaOrderService {
   
  constructor(private http:HttpClient) { }

  placeOrder(order: PlaceOrder<LineItem>):Observable<any[]> {
    return this.http.post<any[]>('http://localhost:8080/pizzaOrder',order)
  }
}
