import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AddPizzaComponent } from './add-pizza/add-pizza.component';
import { HomeComponent } from './home/home.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { GetPizzaComponent } from './get-pizza/get-pizza.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { GetPizzaByidComponent } from './get-pizza-byid/get-pizza-byid.component';
import { UpdatePizzaComponent } from './update-pizza/update-pizza.component';
import { GetpizzaAscComponent } from './getpizza-asc/getpizza-asc.component';
import { GetpizzaDescComponent } from './getpizza-desc/getpizza-desc.component';

const routes: Routes = [
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'home',component:HomeComponent},
  {path:'about',component:AboutComponent},
  {path:'addpizza',component:AddPizzaComponent},
  {path:'getpizza',component:GetPizzaComponent},
  {path:'signin',component:SignInComponent},
  {path:'register',component:SignUpComponent},
  {path:'getpizzabyid',component:GetPizzaByidComponent},
  {path:'update/:id',component:UpdatePizzaComponent},
  {path:'getpizzaAsc',component:GetpizzaAscComponent},
  {path:'getpizzaDesc',component:GetpizzaDescComponent},
  {path:'**',component:PageNotFoundComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }