import { Component, OnInit } from '@angular/core';
import { Pizza } from '../pizza';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-get-pizza-byid',
  templateUrl: './get-pizza-byid.component.html',
  styleUrls: ['./get-pizza-byid.component.css']
})
export class GetPizzaByidComponent implements OnInit {

  constructor(private pservice:PizzaService) { }

  ngOnInit(): void {
  }
public pizza:any=[]

pizzaModel=new Pizza('','','','','')

getPizzaById(pizza:any){
  this.pservice.getPizzaById(this.pizzaModel.pizzaId).subscribe(
    data=>{
      console.log(data)
      this.pizza=data
     }

  )

   }

}
