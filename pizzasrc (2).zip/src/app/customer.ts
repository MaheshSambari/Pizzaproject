export class Customer {
    constructor(public customerName:string,public customerMobile:any,public customerMailId:string,public customerAddress:string,public userPassword:String){

    }
}