import { Component, OnInit } from '@angular/core';
import { Pizza } from '../pizza';
import { PizzaService } from '../pizza.service';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
@Component({
  selector: 'app-update-pizza',
  templateUrl: './update-pizza.component.html',
  styleUrls: ['./update-pizza.component.css']
})
export class UpdatePizzaComponent implements OnInit {

  public 'pizzaModel':Pizza
  'Id':Number
  constructor(private pservice:PizzaService,private activatedroute:ActivatedRoute,private route:Router) { }
   ngOnInit(): void {
  // let pizzaid= this.activatedroute.paramMap.subscribe((prams:ParamMap){
  //   let id=parseInt(prams.get('pizzaId'));
  //   this.Id=id;
  // });
  }


 public result:any
updatePizza(pizza:any){
  console.log(pizza.value)
   this.pservice.updatePizza(pizza.value).subscribe(
      data=>{
        console.log(data)
        this.result=data
        this.route.navigateByUrl('/getpizza')
       }

     )
  }


}
