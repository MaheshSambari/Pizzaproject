import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,FormControl,Validators } from '@angular/forms';
import { UserLogin } from '../user-login';
import { UserService } from '../user.service';
@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  constructor(private fb:FormBuilder,private uservice: UserService) { }

  ngOnInit(): void {
  }
  // loginForm=this.fb.group({
  //   userid : ['',[Validators.required,Validators.pattern('\\d{5}')]],
  //   userpassword:['',[Validators.required,Validators.minLength(5)]]  
   
  //  })
   
  public userModel=new UserLogin('','')
   
   public result:any
   getLogin(loginForm:any){
    //  this.userModel.userId=loginForm.value.userid
    //  this.userModel.userPassword=loginForm.value.userpassword
     console.log(this.userModel)
    this.uservice.login(loginForm.value).subscribe(
      data=>{
        console.log(data)
        this.result=data
       }
     )
}
}
