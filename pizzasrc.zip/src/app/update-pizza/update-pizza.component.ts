import { Component, OnInit } from '@angular/core';
import { Pizza } from '../pizza';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-update-pizza',
  templateUrl: './update-pizza.component.html',
  styleUrls: ['./update-pizza.component.css']
})
export class UpdatePizzaComponent implements OnInit {

  constructor(private pservice:PizzaService) { }
  
   ngOnInit(): void {
     }
 public result:any
pizzaModel = new Pizza('','','','','')

updatePizza(pizza:any){
  console.log(pizza.value)
   this.pservice.updatePizza(pizza.value).subscribe(
      data=>{
        console.log(data)
        this.result=data
        this.pizzaModel = new Pizza('','','','','')
       }

     )
   }


}
