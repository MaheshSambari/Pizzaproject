export class UserLogin {  
    constructor(public userId:any , public password:any){}
}
