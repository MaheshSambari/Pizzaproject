import { Component, OnInit } from '@angular/core';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-get-pizza',
  templateUrl: './get-pizza.component.html',
  styleUrls: ['./get-pizza.component.css']
})
export class GetPizzaComponent implements OnInit {

  constructor(private pservice : PizzaService) { }
public pizza:any=[]
  ngOnInit(): void {
    this.getPizza()
  }

  getPizza(){
    this.pservice.getPizza().subscribe(
      data => this.pizza=data
      )
  }

  public result:any

  deletePizza(pizzaId:Number){
    this.pservice.deletePizza(pizzaId).subscribe(
    data=>{
      console.log(data)
      this.result=data
      this.getPizza()

     }

  )
    }

  updateCost(pizzaId:any){
  }

}
