import { Component, OnInit } from "@angular/core";
import { Customer } from "../customer";


@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  public hasError:boolean=true

addresses=['Adilabad',
  'Bhadradri', 'Kothagudem',
  'Hyderabad',
  'Jagtial',
  'Jangaon',
  'Jayashankar Bhoopalpally',
  'Jogulamba Gadwal',
  'Kamareddy',
  'Karimnagar',
  'Khammam',
  'Komaram Bheem', 'Asifabad',
  'Mahabubabad',
  'Mahabubnagar',
  'Mancherial',
  'Medak',
  'Medchal',
  'Nagarkurnool',
  'Nalgonda',
  'Nirmal',
  'Nizamabad',
  'Peddapalli',
  'Rajanna Sircilla',
  'Rangareddy',
  'Sangareddy',
  'Siddipet',
  'Suryapet',
  'Vikarabad',
  'Wanaparthy',
  'Warangal', '(Rural)',
  'Warangal' ,'(Urban)',
  'Yadadri' ,'Bhuvanagiri']
customerModel=new Customer('','','','default','')

registerCustomer(customer:any){
 console.log(customer.value)
}
validateAddress(address:string){
 if(address=='default'){
 this.hasError=true;
   }
   else {
     this.hasError=false;
   }

}

}
