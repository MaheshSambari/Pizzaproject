import { Component, OnInit } from '@angular/core';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-get-pizza-byid',
  templateUrl: './get-pizza-byid.component.html',
  styleUrls: ['./get-pizza-byid.component.css']
})
export class GetPizzaByidComponent implements OnInit {

  constructor(private pservice:PizzaService) { }

  ngOnInit(): void {
  }
public pizza:any=[]

getPizzaById(pizzaId:Number){
//   this.pservice.getPizzaById(pizzaId).subscribe(
//     data => this.pizza=data
//     )
    alert(pizzaId)

   }

}
