import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pizza } from './pizza';

@Injectable({
  providedIn: 'root'
})
export class PizzaService {
  
  constructor(private http:HttpClient) { }

  public getPizza():Observable<any[]>{
     return this.http.get<any[]>('http://localhost:8080/pizza')
  
    }
    public savePizza(pizza:Pizza):Observable<any[]>{
      return this.http.post<any[]>('http://localhost:8080/pizza',pizza)
   
     }
     public deletePizza(pizzaId:Number):Observable<String>{
      return this.http.delete<String>('http://localhost:8080/pizza/'+pizzaId)
     }
     public getPizzaById(pizzaId:Number):Observable<any[]>{
      return this.http.get<any[]>('http://localhost:8080/pizza/'+pizzaId)
   
     }
     public updatePizza(pizza:Pizza):Observable<any[]>{
      return this.http.put<any[]>('http://localhost:8080/pizza',pizza)
   
     }


}