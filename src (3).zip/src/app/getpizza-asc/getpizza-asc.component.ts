import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-getpizza-asc',
  templateUrl: './getpizza-asc.component.html',
  styleUrls: ['./getpizza-asc.component.css']
})
export class GetpizzaAscComponent implements OnInit {

  constructor(private pservice : PizzaService,private router: Router) { }
  public pizza:any=[]
    ngOnInit(): void {
      this.getPizza()
    }
  
    getPizza(){
      this.pservice.getPizzaAsc().subscribe(
        data => this.pizza=data
        )
    }
  
    public result:any
  
    deletePizza(pizzaId:Number){
      this.pservice.deletePizza(pizzaId).subscribe(
      data=>{
        console.log(data)
        this.result=data
        this.getPizza()
       }
  
    )
      }
  
    updateCost(pizza:any)
    {
     this.router.navigate(['/update',pizza.pizzaId])
    }
  }
  