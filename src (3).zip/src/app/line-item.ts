export class LineItem {
             constructor(public sno:any,public pizzaId:any,public customerId:any,public quantity:any,public size:string){}
}
