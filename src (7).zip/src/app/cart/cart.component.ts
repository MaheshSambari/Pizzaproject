import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LineItem } from '../line-item';
import { LineItemService } from '../line-item.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  ItemModel = new LineItem('','','','','','');
  public msg:any;
  public cart1:any = [];
  public customerId!: number;

  constructor(private lservice:LineItemService,private router:Router) { }
  
  ngOnInit(): void { }

  getCartById(id:any){
     this.customerId=id.customerId
     this.getCart();
   }

  getCart(){
        this.lservice.getCart(this.customerId).subscribe(
        data=>{
            console.log(data);
            this.cart1=data;
            this.ItemModel = new LineItem('','','','','','');
            this.msg='';         
            if(this.cart1.message.length!=0){
                this.ItemModel = new LineItem('','','','','','');
                this.msg=data;
                this.cart1=[];
              }
          },
     error=>{
        console.log(error);
     })
}
   
  updateCart(id:number){
     this.router.navigate(['/updatecartitem',id]);
  }

  deleteCart(id:number){
    // console.log(typeof(id))
    this.lservice.deleteItemById(id).subscribe(
      data=>{
        console.log(data);
        // console.log(this.customerId)
           this.getCart();
       })
  }

}
