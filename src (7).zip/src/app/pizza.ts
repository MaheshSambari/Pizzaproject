export class Pizza {
    constructor(public pizzaId:any,
                public pizzaName:String,
                public pizzaType:String,
                public pizzaCost:any,
                public pizzaDescription:String)
                {
                    
                 }
}
