import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-pizza-orders-by-id',
  templateUrl: './get-pizza-orders-by-id.component.html',
  styleUrls: ['./get-pizza-orders-by-id.component.css']
})
export class GetPizzaOrdersByIdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
