export class Pizza {
    [x: string]: any;
    constructor(public pizzaId:any,
                public pizzaName:String,
                public pizzaType:String,
                public pizzaCost:any,
                public pizzaDescription:String,
                public availableQuantity:any)
                {
                    
                 }
}
