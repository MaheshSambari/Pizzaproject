export class Order {
    constructor(public odredId:any,public orderDescription:string,public orderType:string,customerId:number){}
}
