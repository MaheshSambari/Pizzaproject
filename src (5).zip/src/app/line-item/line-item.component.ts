import { Component, OnInit } from '@angular/core';
import { LineItem } from '../line-item';
import { LineItemService } from '../line-item.service';

@Component({
  selector: 'app-line-item',
  templateUrl: './line-item.component.html',
  styleUrls: ['./line-item.component.css']
})
export class LineItemComponent implements OnInit {

  constructor(private lservice:LineItemService) { }

  ngOnInit(): void {
  }
  
  
  public hasError:boolean=true
  public hasError1:boolean=true
  result:any
  sresult:any
  sizes=['small','medium','large']
  quantitys=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]

  ItemModel = new LineItem('','','','default','default','')
  validateSize(size:string){
    if(size=='default'){
    this.hasError=true;
      }
      else {
        this.hasError=false;
      }
   
   }
   validateQuantity(Quantity1:string){
    if(Quantity1=='default'){
    this.hasError1=true;
      }
      else {
        this.hasError1=false;
      }
   
   }

  addItem(lineitem:any){
    //alert();
    //console.log(this.ItemModel)
    this.lservice.addItem(this.ItemModel).subscribe(data=>{
      this.result=data
      this.sresult=''
      this.ItemModel = new LineItem('','','','','','')
      if(this.result.successMessage.length!=0){
        this.sresult=data
        this.result=''
        this.ItemModel = new LineItem('','','','','','')
      }
    },
    error=>{
      this.result=error.error;
      this.sresult=''
      this.ItemModel = new LineItem('','','','','','')
    }
    )
  
     }

}
