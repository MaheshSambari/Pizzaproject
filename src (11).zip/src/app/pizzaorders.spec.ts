import { Pizzaorders } from './pizzaorders';

describe('Pizzaorders', () => {
  it('should create an instance', () => {
    expect(new Pizzaorders()).toBeTruthy();
  });
});
