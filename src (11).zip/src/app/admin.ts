export class Admin {
    constructor(public adminId:any ,
        public adminName:any, 
        public adminPassword:any){}

}
